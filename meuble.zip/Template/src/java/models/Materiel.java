/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import connection.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author tahir
 */
public class Materiel {
    int idMateriel;
    String nom;

    public int getIdMateriel() {
        return idMateriel;
    }

    public void setIdMateriel(int idMateriel) {
        this.idMateriel = idMateriel;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) throws Exception {
            this.nom = nom;
    }

    public Materiel() {
    }

    public Materiel(int idMateriel, String nom) throws Exception {
        this.setIdMateriel(idMateriel);
        this.setNom(nom);
    }
    
    public Materiel(String nom) throws Exception {
        this.setNom(nom);
    }
    
    public void insert()throws Exception
    {
        Connection connecting = new Connect().getConnection();
        String req = "INSERT INTO materiel(nom) VALUES (?)";
        PreparedStatement pstmt = connecting.prepareStatement(req); 
        pstmt.setString(1, this.getNom());
        pstmt.executeUpdate();
        connecting.close();
    }
    
    public Vector<Materiel> getAll()throws Exception{
        Connection connecting=new Connect().getConnection();
        Statement stmt = connecting.createStatement();
   	String req = "select * from materiel";
        ResultSet render = stmt.executeQuery(req);
        Vector<Materiel> result = new Vector<Materiel>();
        while(render.next()){
            result.add(new Materiel(render.getInt(1),render.getString(2)));
	}
        stmt.close();
        connecting.close();
        return result;
    }
}
