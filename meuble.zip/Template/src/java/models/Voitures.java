/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import connection.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;

/**
 *
 * @author tahir
 */
public class Voitures {
    int id;
    String marque;
    String matricule;
    String modele;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public Voitures() {
    }

    public Voitures(String marque, String matricule, String modele) {
        this.setMarque(marque);
        this.setMatricule(matricule);
        this.setModele(modele);
    }
    
    public Voitures(int id, String marque, String matricule, String modele) {
        this.setId(id);
        this.setMarque(marque);
        this.setMatricule(matricule);
        this.setModele(modele);
    }
    
    public void insert()throws Exception
    {
        Connection connecting = new Connect().getConnection();
        String req = "INSERT INTO voitures (marque, matricule, modele) VALUES (?,?,?)";
        PreparedStatement pstmt = connecting.prepareStatement(req); 
        pstmt.setString(1, this.getMarque());
        pstmt.setString(2, this.getMatricule());
        pstmt.setString(3, this.getModele());
        pstmt.executeUpdate();
        connecting.close();
    }
    
    public Vector<Voitures> getAll()throws Exception{
        Connection connecting=new Connect().getConnection();
        Statement stmt = connecting.createStatement();
   	String req = "select * from voitures";
        ResultSet render = stmt.executeQuery(req);
        Vector<Voitures> result = new Vector<Voitures>();
        while(render.next()){
            result.add(new Voitures(render.getInt(1),render.getString(2),render.getString(3),render.getString(4)));
	}
        stmt.close();
        connecting.close();
        return result;
    }
}
